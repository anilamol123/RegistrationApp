﻿using DotnetLoginRegApp.Data;
using DotnetLoginRegApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace DotnetLoginRegApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ContactsController : Controller
    {
        private readonly ContactsAPIDbContext dbContext;

        public ContactsController(ContactsAPIDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        [HttpGet]
        public async Task<IActionResult> GetContacts()
        {
            return Ok(await dbContext.Contacts.ToListAsync());
        }
        [HttpPost]
        public async Task<IActionResult> AddContact(AddContactRequest addContact)
        {
            var contact = new Contact()
            {
                Id = Guid.NewGuid(),
                FullName = addContact.FullName,
                Email = addContact.Email,
                Address = addContact.Address,
                Phone = addContact.Phone
            };
            await dbContext.Contacts.AddAsync(contact);
            await dbContext.SaveChangesAsync();
            return Ok(contact);
        }

        [HttpPut]
        [Route("{id:guid}")]
        public async Task<IActionResult> UpdateContact([FromRoute] Guid id,UpdateContactRequest updateContact)
        {
            var contact = dbContext.Contacts.Find(id);
            if(contact!=null)
            {
                contact.FullName = updateContact.FullName;
                contact.Address = updateContact.Address;
                contact.Phone = updateContact.Phone;
                contact.Email = updateContact.Email;
                await dbContext.SaveChangesAsync();
            }
            return NotFound();
        }
    }
}
