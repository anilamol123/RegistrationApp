﻿using Microsoft.EntityFrameworkCore;

namespace DotnetLoginRegApp.Data
{
    public class ContactsAPIDbContext:DbContext
    {
        public ContactsAPIDbContext(DbContextOptions<ContactsAPIDbContext> options) : base(options)
        {
        }
        public DbSet<DotnetLoginRegApp.Models.Contact> Contacts { get; set; }
    }
}
